export type Role = 'cliente' | 'repartidor' | 'despachador';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: Role;
  activeOrderId?: string;
  vehicleInfo?: string;
  rating?: number;
  ratingCount?: number;
}

export type OrderStatus = 'pendiente' | 'en_camino' | 'entregado' | 'cancelado';

export interface Coords {
  lat: number;
  lng: number;
}

export interface Order {
  id: string;
  customerId: string;
  courierId?: string;
  status: OrderStatus;
  customerAddress: string;
  customerCoords: Coords;
  courierCoords?: Coords;
  isRated?: boolean;
  createdAt: any;
  updatedAt: any;
}
