import React, { useState, useEffect } from 'react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  onSnapshot, 
  collection, 
  query, 
  where, 
  updateDoc, 
  serverTimestamp,
  addDoc,
  getDocFromServer
} from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { 
  MapPin, 
  Truck, 
  Package, 
  CheckCircle2, 
  LogOut, 
  Navigation,
  Loader2,
  AlertCircle,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Order, OrderStatus, Role, UserProfile, Coords } from './types';

// --- Leaflet Icon Fix ---
import markerIcon from 'leaflet/dist/images/marker-icon.png';
import markerShadow from 'leaflet/dist/images/marker-shadow.png';

const DefaultIcon = L.icon({
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

// --- Error Helper ---
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// --- Map Component ---
function MapUpdater({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, 15);
  }, [center, map]);
  return null;
}

// --- Distance & ETA Helpers ---
function calculateDistance(c1: Coords, c2: Coords) {
  const R = 6371e3; // metres
  const φ1 = c1.lat * Math.PI/180;
  const φ2 = c2.lat * Math.PI/180;
  const Δφ = (c2.lat-c1.lat) * Math.PI/180;
  const Δλ = (c2.lng-c1.lng) * Math.PI/180;

  const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
          Math.cos(φ1) * Math.cos(φ2) *
          Math.sin(Δλ/2) * Math.sin(Δλ/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

  return R * c; // in metres
}

function getETA(distanceMetres: number) {
  const speedMPS = 8.33; // ~30 km/h in m/s
  const seconds = distanceMetres / speedMPS;
  return Math.ceil(seconds / 60);
}

// --- App Component ---
export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [courierProfile, setCourierProfile] = useState<UserProfile | null>(null);
  const [availableOrders, setAvailableOrders] = useState<Order[]>([]);
  const [couriers, setCouriers] = useState<UserProfile[]>([]);
  const [selectedOrderForAssignment, setSelectedOrderForAssignment] = useState<string | null>(null);

  const eta = activeOrder?.courierCoords ? getETA(calculateDistance(activeOrder.courierCoords, activeOrder.customerCoords)) : null;

  // 1. Initial connection test
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    }
    testConnection();
  }, []);

  // 2. Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
          if (userDoc.exists()) {
            setProfile(userDoc.data() as UserProfile);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
        }
      } else {
        setProfile(null);
        setActiveOrder(null);
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);
  // 4. Data Sync
  useEffect(() => {
    if (!user || !profile) return;

    if (profile.role === 'cliente') {
      const unsubProfile = onSnapshot(doc(db, 'users', user.uid), (snap) => {
        if (snap.exists()) {
          const data = snap.data() as UserProfile;
          setProfile(data);
          if (data.activeOrderId) {
            onSnapshot(doc(db, 'orders', data.activeOrderId), (orderSnap) => {
              if (orderSnap.exists()) {
                const orderData = { id: orderSnap.id, ...orderSnap.data() } as Order;
                setActiveOrder(orderData);
                if (orderData.status === 'entregado' && !orderData.isRated) {
                  setShowRatingModal(true);
                }
              }
            });
          } else setActiveOrder(null);
        }
      });
      return unsubProfile;
    }

    if (profile.role === 'repartidor') {
      const q = query(collection(db, 'orders'), where('status', '==', 'pendiente'));
      const unsubPending = onSnapshot(q, (snap) => {
        setAvailableOrders(snap.docs.map(d => ({ id: d.id, ...d.data() } as Order)));
      });
      const unsubProfile = onSnapshot(doc(db, 'users', user.uid), (snap) => {
        const data = snap.data() as UserProfile;
        if (data?.activeOrderId) {
          onSnapshot(doc(db, 'orders', data.activeOrderId), (orderSnap) => {
            if (orderSnap.exists()) setActiveOrder({ id: orderSnap.id, ...orderSnap.data() } as Order);
          });
        } else setActiveOrder(null);
      });
      return () => { unsubPending(); unsubProfile(); };
    }

    if (profile.role === 'despachador') {
      const q = query(collection(db, 'orders'), where('status', 'in', ['pendiente', 'en_camino']));
      const unsubOrders = onSnapshot(q, (snap) => {
        setAvailableOrders(snap.docs.map(d => ({ id: d.id, ...d.data() } as Order)));
      });
      const cq = query(collection(db, 'users'), where('role', '==', 'repartidor'));
      const unsubCouriers = onSnapshot(cq, (snap) => {
        setCouriers(snap.docs.map(d => d.data() as UserProfile));
      });
      return () => { unsubOrders(); unsubCouriers(); };
    }
  }, [user, profile?.role]);

  // 5. Courier Profile Sync (for customers)
  useEffect(() => {
    if (profile?.role === 'cliente' && activeOrder?.courierId) {
      const unsubCourier = onSnapshot(doc(db, 'users', activeOrder.courierId), (snap) => {
        if (snap.exists()) {
          setCourierProfile(snap.data() as UserProfile);
        }
      });
      return unsubCourier;
    } else {
      setCourierProfile(null);
    }
  }, [profile?.role, activeOrder?.courierId]);

  // --- Actions ---
  const handleLogin = async (role: Role) => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const userRef = doc(db, 'users', result.user.uid);
      const userDoc = await getDoc(userRef);
      if (!userDoc.exists()) {
        const newProfile: UserProfile = { 
          uid: result.user.uid, 
          email: result.user.email!, 
          displayName: result.user.displayName || 'Usuario', 
          photoURL: result.user.photoURL || '', 
          role 
        };
        if (role === 'repartidor') {
          newProfile.vehicleInfo = 'Honda Wave • Blanca • EN-V1O';
          newProfile.rating = 4.9;
          newProfile.ratingCount = 10;
        }
        await setDoc(userRef, newProfile);
        setProfile(newProfile);
      } else setProfile(userDoc.data() as UserProfile);
    } catch (error) { console.error("Login error", error); }
  };

  const assignOrderManually = async (orderId: string, courierUid: string) => {
    if (!user || profile?.role !== 'despachador') return;
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        courierId: courierUid,
        status: 'en_camino',
        updatedAt: serverTimestamp(),
        courierCoords: { lat: 4.6117, lng: -74.0827 } 
      });
      setSelectedOrderForAssignment(null);
    } catch (error) { handleFirestoreError(error, OperationType.WRITE, `orders/${orderId}`); }
  };

  const createOrder = async () => {
    if (!user || !profile) return;
    setLoading(true);
    try {
      const orderData = { customerId: user.uid, status: 'pendiente', customerAddress: 'Calle Principal 123, Ciudad', customerCoords: { lat: 4.6097, lng: -74.0817 }, createdAt: serverTimestamp(), updatedAt: serverTimestamp() };
      const orderRef = await addDoc(collection(db, 'orders'), orderData);
      await updateDoc(doc(db, 'users', user.uid), { activeOrderId: orderRef.id });
    } catch (error) { handleFirestoreError(error, OperationType.WRITE, 'orders'); } finally { setLoading(false); }
  };

  const acceptOrder = async (orderId: string) => {
    if (!user || !profile) return;
    try {
      await updateDoc(doc(db, 'orders', orderId), { courierId: user.uid, status: 'en_camino', updatedAt: serverTimestamp(), courierCoords: { lat: 4.6117, lng: -74.0827 } });
      await updateDoc(doc(db, 'users', user.uid), { activeOrderId: orderId });
    } catch (error) { handleFirestoreError(error, OperationType.WRITE, `orders/${orderId}`); }
  };

  const updateLocationAsCourier = async () => {
    if (!activeOrder || !user) return;
    const newCoords = { lat: activeOrder.courierCoords!.lat + (Math.random() - 0.5) * 0.001, lng: activeOrder.courierCoords!.lng + (Math.random() - 0.5) * 0.001 };
    try { await updateDoc(doc(db, 'orders', activeOrder.id), { courierCoords: newCoords, updatedAt: serverTimestamp() }); } catch (error) { console.error("Update loc err", error); }
  };

  const [showConfirmDelivery, setShowConfirmDelivery] = useState(false);
  const [showConfirmCancel, setShowConfirmCancel] = useState(false);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [currentRating, setCurrentRating] = useState(5);

  const submitRating = async () => {
    if (!activeOrder || !courierProfile || !user) return;
    try {
      const newRatingCount = (courierProfile.ratingCount || 0) + 1;
      const newRating = ((courierProfile.rating || 0) * (courierProfile.ratingCount || 0) + currentRating) / newRatingCount;

      await setDoc(doc(db, 'users', activeOrder.courierId!, 'reviews', activeOrder.id), {
        rating: currentRating,
        customerId: user.uid,
        createdAt: serverTimestamp()
      });

      await updateDoc(doc(db, 'users', activeOrder.courierId!), {
        rating: newRating,
        ratingCount: newRatingCount
      });

      await updateDoc(doc(db, 'orders', activeOrder.id), {
        isRated: true,
        updatedAt: serverTimestamp()
      });

      setActiveOrder(null);
      setCourierProfile(null);
      setShowRatingModal(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${activeOrder.courierId}/reviews`);
    }
  };

  const cancelOrder = async () => {
    if (!activeOrder || !user || activeOrder.status !== 'pendiente') return;
    try {
      await updateDoc(doc(db, 'orders', activeOrder.id), { status: 'cancelado', updatedAt: serverTimestamp() });
      await updateDoc(doc(db, 'users', user.uid), { activeOrderId: null });
      setShowConfirmCancel(false);
    } catch (error) { handleFirestoreError(error, OperationType.WRITE, `orders/${activeOrder.id}`); }
  };

  const markDelivered = async () => {
    if (!activeOrder || !user) return;
    try {
      await updateDoc(doc(db, 'orders', activeOrder.id), { status: 'entregado', updatedAt: serverTimestamp() });
      await updateDoc(doc(db, 'users', user.uid), { activeOrderId: null });
      setShowConfirmDelivery(false);
    } catch (error) { handleFirestoreError(error, OperationType.WRITE, `orders/${activeOrder.id}`); }
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-zinc-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  // --- RENDERING ---

  if (!user) {
    return (
      <div className="min-h-screen bg-[#FDFCFB] flex flex-col items-center justify-center p-6">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full bg-white rounded-[40px] p-10 shadow-2xl shadow-orange-100 border border-slate-50"
        >
          <div className="flex items-center gap-4 mb-10">
            <div className="p-3 bg-orange-500 rounded-[22px] shadow-lg shadow-orange-200">
              <Truck className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">EnvioExpress</h1>
          </div>
          
          <h2 className="text-2xl font-black text-slate-900 mb-2">Bienvenido</h2>
          <p className="text-slate-500 font-medium mb-10">Gestiona tus entregas con estilo y rapidez.</p>
          
          <div className="space-y-4">
            <button 
              onClick={() => handleLogin('cliente')}
              className="w-full group flex items-center justify-between p-6 bg-white border-2 border-slate-50 rounded-[32px] hover:border-orange-500 hover:bg-orange-50/30 transition-all text-left shadow-sm"
            >
              <div className="flex items-center gap-5">
                <div className="p-3 bg-orange-100 rounded-2xl group-hover:bg-orange-500 transition-colors">
                  <Package className="w-6 h-6 text-orange-600 group-hover:text-white" />
                </div>
                <div>
                  <div className="font-black text-slate-900">Soy Cliente</div>
                  <div className="text-sm text-slate-400 font-bold uppercase tracking-tighter">Rastrear mi pedido</div>
                </div>
              </div>
            </button>

            <button 
              onClick={() => handleLogin('repartidor')}
              className="w-full group flex items-center justify-between p-6 bg-white border-2 border-slate-50 rounded-[32px] hover:border-orange-600 hover:bg-orange-50/30 transition-all text-left shadow-sm"
            >
              <div className="flex items-center gap-5">
                <div className="p-3 bg-orange-100 rounded-2xl group-hover:bg-orange-600 transition-colors">
                  <Truck className="w-6 h-6 text-orange-600 group-hover:text-white" />
                </div>
                <div>
                  <div className="font-black text-slate-900">Soy Repartidor</div>
                  <div className="text-sm text-slate-400 font-bold uppercase tracking-tighter">Entregar pedidos</div>
                </div>
              </div>
            </button>

            <button 
              onClick={() => handleLogin('despachador')}
              className="w-full group flex items-center justify-between p-6 bg-white border-2 border-zinc-100 rounded-[32px] hover:border-orange-600 hover:bg-zinc-50 transition-all text-left shadow-sm"
            >
              <div className="flex items-center gap-5">
                <div className="p-3 bg-zinc-100 rounded-2xl group-hover:bg-zinc-800 transition-colors">
                  <Navigation className="w-6 h-6 text-zinc-600 group-hover:text-white" />
                </div>
                <div>
                  <div className="font-black text-slate-900">Soy Despachador</div>
                  <div className="text-sm text-slate-400 font-bold uppercase tracking-tighter">Asignación Manual</div>
                </div>
              </div>
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FDFCFB] flex flex-col font-sans relative">
      <AnimatePresence>
        {showConfirmDelivery && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white rounded-[40px] p-10 max-w-md w-full shadow-2xl border border-slate-100 text-center"
            >
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-2">¿Confirmar entrega?</h3>
              <p className="text-slate-500 font-medium mb-8 leading-relaxed">
                Asegúrate de estar en la ubicación del cliente antes de marcar el pedido como entregado.
              </p>
              <div className="flex flex-col gap-3">
                <button 
                  onClick={markDelivered}
                  className="w-full p-5 bg-green-600 text-white rounded-[24px] font-black hover:bg-green-700 transition-all shadow-lg shadow-green-100"
                >
                  Confirmar Entrega
                </button>
                <button 
                  onClick={() => setShowConfirmDelivery(false)}
                  className="w-full p-5 bg-slate-100 text-slate-600 rounded-[24px] font-black hover:bg-slate-200 transition-all"
                >
                  Cancelar
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showRatingModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white rounded-[40px] p-10 max-w-md w-full shadow-2xl border border-slate-100 text-center"
            >
              <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="w-10 h-10 text-orange-600 fill-current" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-2">¡Pedido Entregado!</h3>
              <p className="text-slate-500 font-medium mb-8 leading-relaxed">
                ¿Qué te pareció el servicio de {courierProfile?.displayName || 'tu repartidor'}?
              </p>
              
              <div className="flex justify-center gap-2 mb-10">
                {[1,2,3,4,5].map(star => (
                  <button 
                    key={star} 
                    onClick={() => setCurrentRating(star)}
                    className="p-1 focus:outline-none transition-transform hover:scale-110 active:scale-95"
                  >
                    <Star className={`w-10 h-10 ${star <= currentRating ? 'text-yellow-400 fill-current' : 'text-slate-200'}`} />
                  </button>
                ))}
              </div>

              <div className="flex flex-col gap-3">
                <button 
                  onClick={submitRating}
                  className="w-full p-5 bg-orange-600 text-white rounded-[24px] font-black hover:bg-orange-700 transition-all shadow-lg shadow-orange-100"
                >
                  Enviar Calificación
                </button>
                <button 
                  onClick={() => {
                    setActiveOrder(null);
                    setShowRatingModal(false);
                  }}
                  className="w-full p-5 bg-slate-100 text-slate-600 rounded-[24px] font-black hover:bg-slate-200 transition-all"
                >
                  Omitir
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showConfirmCancel && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[2000] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white rounded-[40px] p-10 max-w-md w-full shadow-2xl border border-slate-100 text-center"
            >
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <AlertCircle className="w-10 h-10 text-red-600" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 mb-2">¿Cancelar pedido?</h3>
              <p className="text-slate-500 font-medium mb-8 leading-relaxed">
                Esta acción no se puede deshacer. El pedido será cancelado permanentemente.
              </p>
              <div className="flex flex-col gap-3">
                <button 
                  onClick={cancelOrder}
                  className="w-full p-5 bg-red-600 text-white rounded-[24px] font-black hover:bg-red-700 transition-all shadow-lg shadow-red-100"
                >
                  Cancelar Pedido
                </button>
                <button 
                  onClick={() => setShowConfirmCancel(false)}
                  className="w-full p-5 bg-slate-100 text-slate-600 rounded-[24px] font-black hover:bg-slate-200 transition-all"
                >
                  Volver
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="bg-white border-b border-slate-100 p-6 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-orange-500 p-2 rounded-xl">
              <Truck className="w-5 h-5 text-white" />
            </div>
            <span className="font-black text-xl tracking-tight text-slate-900">EnvioExpress</span>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <div className="text-sm font-black text-slate-900 leading-none mb-1">{user.displayName}</div>
                <div className="text-[10px] uppercase tracking-widest text-orange-500 font-black">{profile?.role}</div>
              </div>
              <div className="relative">
                {user.photoURL && <img src={user.photoURL} alt="Avatar" className="w-10 h-10 rounded-2xl shadow-sm border-2 border-white ring-1 ring-slate-100" referrerPolicy="no-referrer" />}
                <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white rounded-full"></div>
              </div>
            </div>
            <button onClick={() => signOut(auth)} className="p-2 hover:bg-slate-50 rounded-xl text-slate-400 transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col lg:flex-row gap-8 p-8 max-w-7xl mx-auto w-full overflow-hidden">
        {/* Sidebar / Controls */}
        <div className="w-full lg:w-[400px] flex flex-col gap-8 shrink-0">
          <AnimatePresence mode="wait">
            {!activeOrder && profile?.role !== 'despachador' && (
              <motion.div 
                key="no-order"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-white rounded-[40px] p-8 shadow-xl shadow-slate-100 border border-slate-50"
              >
                <h3 className="font-black text-2xl text-slate-900 mb-6 flex items-center gap-3">
                  {profile?.role === 'cliente' ? <Package className="text-orange-500" /> : <Truck className="text-orange-500" />}
                  {profile?.role === 'cliente' ? 'Tu Pedido' : 'Pedidos'}
                </h3>
                
                {profile?.role === 'cliente' ? (
                  <div className="space-y-6">
                    <p className="text-slate-500 font-medium leading-relaxed">¿Necesitas enviar algo rápido? Solicita un repartidor ahora mismo.</p>
                    <button 
                      onClick={createOrder}
                      className="w-full bg-orange-500 text-white font-black py-4 rounded-[22px] hover:bg-orange-600 transition-all shadow-xl shadow-orange-100 active:scale-[0.98]"
                    >
                      Solicitar Envío Demo
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {availableOrders.length === 0 ? (
                      <div className="text-center py-12 bg-slate-50 rounded-[32px] border border-dashed border-slate-200">
                        <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                        <p className="text-slate-400 font-bold text-sm uppercase tracking-widest">Esperando pedidos...</p>
                      </div>
                    ) : (
                      availableOrders.map(order => (
                        <div key={order.id} className="p-6 bg-slate-50 border border-slate-100 rounded-[32px] hover:border-orange-500 transition-all group">
                          <div className="flex justify-between items-center mb-4">
                            <span className="text-[10px] font-black text-orange-500 bg-orange-50 px-3 py-1.5 rounded-full uppercase tracking-widest">PEDIDO #...{order.id.slice(-4)}</span>
                            <span className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
                          </div>
                          <p className="text-slate-900 font-black mb-6 line-clamp-2">{order.customerAddress}</p>
                          <button 
                            onClick={() => acceptOrder(order.id)}
                            className="w-full bg-white text-slate-900 text-sm font-black py-3 rounded-2xl border border-slate-200 group-hover:bg-orange-500 group-hover:text-white group-hover:border-transparent transition-all shadow-sm"
                          >
                            Aceptar Entrega
                          </button>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </motion.div>
            )}

            {/* Dispatcher View */}
            {profile?.role === 'despachador' && (
              <motion.div 
                key="dispatcher-view"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-[40px] p-8 shadow-xl shadow-slate-100 border border-slate-50 h-full flex flex-col"
              >
                <h3 className="font-black text-2xl text-slate-900 mb-6 flex items-center gap-3">
                  <Navigation className="text-orange-500" /> Despacho
                </h3>
                
                <div className="space-y-6 flex-grow overflow-y-auto">
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">Pedidos Pendientes</h4>
                    <div className="space-y-3">
                      {availableOrders.filter(o => o.status === 'pendiente').map(order => (
                        <div 
                          key={order.id} 
                          onClick={() => setSelectedOrderForAssignment(order.id)}
                          className={`p-4 rounded-[28px] border-2 transition-all cursor-pointer ${selectedOrderForAssignment === order.id ? 'border-orange-500 bg-orange-50/50' : 'border-slate-50 bg-slate-50 hover:border-slate-200'}`}
                        >
                          <p className="text-sm font-black text-slate-900 mb-1 line-clamp-1">{order.customerAddress}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">ID: #{order.id.slice(-4)}</p>
                        </div>
                      ))}
                      {availableOrders.filter(o => o.status === 'pendiente').length === 0 && <p className="text-sm text-slate-400 italic">No hay pedidos pendientes.</p>}
                    </div>
                  </div>

                  {selectedOrderForAssignment && (
                    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                      <h4 className="text-[10px] font-black uppercase tracking-widest text-orange-500 mb-4">Asignar Repartidor</h4>
                      <div className="grid grid-cols-1 gap-2">
                        {couriers.map(courier => (
                          <button
                            key={courier.uid}
                            onClick={() => assignOrderManually(selectedOrderForAssignment, courier.uid)}
                            className="flex items-center gap-3 p-4 bg-white border border-slate-100 rounded-2xl hover:border-orange-500 text-left transition-all group"
                          >
                            <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center group-hover:bg-orange-100">
                               <Truck className="w-5 h-5 text-slate-400 group-hover:text-orange-500" />
                            </div>
                            <div>
                              <div className="text-sm font-black text-slate-900">{courier.displayName}</div>
                              <div className="text-[10px] font-bold text-slate-400 uppercase">Disponible</div>
                            </div>
                          </button>
                        ))}
                        {couriers.length === 0 && <p className="text-sm text-slate-400 italic">No hay repartidores disponibles.</p>}
                      </div>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            )}

            {activeOrder && profile?.role !== 'despachador' && (
              <motion.div 
                key="active-order"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-white rounded-[40px] shadow-2xl border border-slate-50 flex flex-col h-full overflow-hidden"
              >
                <div className="p-8 pb-4">
                  <div className="flex items-center justify-between mb-8">
                    <div className="bg-orange-500 p-2 rounded-2xl shadow-lg shadow-orange-100">
                      <Truck className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">PEDIDO #{activeOrder.id.slice(-6).toUpperCase()}</span>
                  </div>
                  
                  <h1 className="text-3xl font-black text-slate-900 leading-tight mb-2">
                    {activeOrder.status === 'en_camino' ? '¡Tu pedido está en camino!' : 
                     activeOrder.status === 'entregado' ? '¡Pedido entregado!' : 'Buscando repartidor...'}
                  </h1>
                  <p className="text-slate-500 font-medium">
                    {activeOrder.status === 'en_camino' ? (
                      <>Llegada estimada en <span className="text-orange-500 font-black">{eta || '--'} minutos</span></>
                    ) : activeOrder.status === 'cancelado' ? (
                      <span className="text-red-500 font-black">Este pedido ha sido cancelado</span>
                    ) : (
                      <>Estado: <span className="text-orange-500 font-black capitalize">{activeOrder.status}</span></>
                    )}
                  </p>
                </div>

                {/* Progress Stepper */}
                <div className="px-8 py-6 space-y-8 flex-grow">
                  <div className="flex gap-5">
                    <div className="flex flex-col items-center shrink-0">
                      <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center text-white shadow-xl shadow-orange-100">
                        <CheckCircle2 className="w-5 h-5 stroke-[3px]" />
                      </div>
                      <div className="w-0.5 h-full bg-orange-100 my-1"></div>
                    </div>
                    <div className="pb-4">
                      <h3 className="font-black text-slate-900">Pedido Confirmado</h3>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Hace 15 min</p>
                    </div>
                  </div>

                  <div className="flex gap-5">
                    <div className="flex flex-col items-center shrink-0">
                      <div className={`${activeOrder.status !== 'pendiente' ? 'bg-orange-500' : 'bg-slate-100'} w-8 h-8 rounded-full flex items-center justify-center text-white shadow-xl transition-colors`}>
                        {activeOrder.status !== 'pendiente' ? <CheckCircle2 className="w-5 h-5 stroke-[3px]" /> : <div className="w-2 h-2 rounded-full bg-slate-300" />}
                      </div>
                      <div className={`w-0.5 h-full ${activeOrder.status !== 'pendiente' ? 'bg-orange-100' : 'bg-slate-50'} my-1`}></div>
                    </div>
                    <div className="pb-4">
                      <h3 className={`font-black ${activeOrder.status !== 'pendiente' ? 'text-slate-900' : 'text-slate-300'}`}>En Preparación</h3>
                      <p className="text-xs text-slate-400 font-bold uppercase tracking-wider">Listo para despacho</p>
                    </div>
                  </div>

                  <div className="flex gap-5">
                    <div className="flex flex-col items-center shrink-0">
                      {activeOrder.status === 'en_camino' ? (
                        <div className="w-10 h-10 -ml-1 rounded-full bg-white border-[4px] border-orange-500 flex items-center justify-center ring-[6px] ring-orange-50 ring-inset">
                          <div className="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></div>
                        </div>
                      ) : activeOrder.status === 'entregado' ? (
                        <div className="w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center text-white shadow-xl">
                          <CheckCircle2 className="w-5 h-5 stroke-[3px]" />
                        </div>
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
                          <div className="w-2 h-2 rounded-full bg-slate-300" />
                        </div>
                      )}
                    </div>
                    <div className="pb-4">
                      <h3 className={`font-black ${activeOrder.status !== 'pendiente' ? 'text-slate-900' : 'text-slate-300'}`}>Repartidor en camino</h3>
                      {activeOrder.status === 'en_camino' && <p className="text-xs text-orange-500 font-bold uppercase tracking-wider">Síguelo en el mapa</p>}
                    </div>
                  </div>
                </div>

                {/* Delivery Driver Info Card */}
                <div className="p-6 m-6 bg-slate-50 rounded-[40px] border border-slate-100 mt-auto">
                   {profile?.role === 'repartidor' && activeOrder.status === 'en_camino' ? (
                     <div className="space-y-3">
                       <button 
                        onClick={updateLocationAsCourier}
                        className="w-full bg-orange-500 text-white font-black py-4 rounded-[22px] flex items-center justify-center gap-3 shadow-xl shadow-orange-100 hover:bg-orange-600 transition-all active:scale-[0.98]"
                      >
                        <Navigation className="w-5 h-5" /> Simular Ubicación
                      </button>
                      <button 
                        onClick={() => setShowConfirmDelivery(true)}
                        className="w-full bg-slate-900 text-white font-black py-4 rounded-[22px] flex items-center justify-center gap-3 hover:bg-slate-800 transition-all"
                      >
                        <CheckCircle2 className="w-5 h-5" /> Marcar Entregado
                      </button>
                     </div>
                   ) : (
                    <>
                      <div className="flex items-center gap-4 mb-6">
                        <div className="w-16 h-16 rounded-[24px] bg-orange-100 border-2 border-white shadow-sm overflow-hidden relative flex items-center justify-center">
                          {activeOrder.courierId ? (
                            courierProfile?.photoURL ? (
                              <img src={courierProfile.photoURL} alt={courierProfile.displayName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <Truck className="w-8 h-8 text-orange-500" />
                            )
                          ) : (
                            <Loader2 className="w-6 h-6 text-orange-500 animate-spin" />
                          )}
                          <div className={`absolute bottom-1 right-1 w-4 h-4 ${activeOrder.courierId ? 'bg-green-500' : 'bg-slate-300'} border-2 border-white rounded-full`}></div>
                        </div>
                        <div>
                          <h4 className="font-black text-slate-900">{courierProfile?.displayName || (activeOrder.courierId ? 'Cargando...' : 'Asignando...')}</h4>
                          <div className="flex items-center gap-2">
                             <div className="flex items-center">
                               {[1,2,3,4,5].map(i => (
                                 <motion.div key={i}>
                                   <Star className={`w-3 h-3 ${i <= (courierProfile?.rating || 0) ? 'text-yellow-400 fill-current' : 'text-slate-300'}`} />
                                 </motion.div>
                               ))}
                             </div>
                             <span className="text-xs font-black text-slate-700">{courierProfile?.rating?.toFixed(1) || (activeOrder.courierId ? '...' : '0.0')}</span>
                          </div>
                          <p className="text-[10px] text-slate-400 font-black uppercase tracking-tighter mt-1">
                            {courierProfile?.vehicleInfo || (activeOrder.courierId ? 'Vehículo de entrega' : 'Espere un momento')}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-3">
                        <button className="flex-1 bg-white py-4 rounded-[22px] text-xs font-black border border-slate-200 hover:bg-slate-100 transition-colors uppercase tracking-widest">Llamar</button>
                        <button className="flex-[1.5] bg-orange-500 py-4 rounded-[22px] text-xs font-black text-white shadow-xl shadow-orange-100 hover:bg-orange-600 transition-all uppercase tracking-widest">Chatear</button>
                      </div>
                      {profile?.role === 'cliente' && activeOrder.status === 'pendiente' && (
                        <button 
                          onClick={() => setShowConfirmCancel(true)}
                          className="w-full mt-4 text-red-500 font-black text-[10px] uppercase tracking-widest hover:text-red-600 transition-colors py-2"
                        >
                          Cancelar Pedido
                        </button>
                      )}
                    </>
                   )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Map View */}
        <div className="flex-1 min-h-[500px] lg:min-h-0 bg-white rounded-[40px] p-3 shadow-2xl shadow-slate-100 border border-slate-50 relative overflow-hidden">
          <div className="absolute inset-0 z-0 opacity-40 pointer-events-none" 
            style={{ backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)', backgroundSize: '40px 40px' }} 
          />
          
          <MapContainer 
            center={[4.6097, -74.0817]} 
            zoom={13} 
            style={{ height: '100%', width: '100%', borderRadius: '2rem', border: '1px solid #f1f5f9' }}
            scrollWheelZoom={true}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {profile?.role === 'despachador' && availableOrders.map(order => (
               <React.Fragment key={order.id}>
                  <Marker position={[order.customerCoords.lat, order.customerCoords.lng]}>
                    <Popup>
                      <div className="p-2">
                        <p className="font-black text-sm">{order.status === 'pendiente' ? 'Pendiente' : 'En Camino'}</p>
                        <p className="text-xs text-slate-500">{order.customerAddress}</p>
                      </div>
                    </Popup>
                  </Marker>
                  {order.courierCoords && (
                    <Marker 
                      position={[order.courierCoords.lat, order.courierCoords.lng]}
                      icon={L.divIcon({
                        className: 'custom-icon',
                        html: '<div class="pulse-marker"></div>',
                        iconSize: [20, 20],
                        iconAnchor: [10, 10]
                      })}
                    >
                      <Popup>Repartidor: {order.courierId}</Popup>
                    </Marker>
                  )}
               </React.Fragment>
            ))}

            {activeOrder && (
              <>
                <Marker position={[activeOrder.customerCoords.lat, activeOrder.customerCoords.lng]}>
                  <Popup>Ubicación del Cliente</Popup>
                </Marker>
                {activeOrder.courierCoords && (
                  <Marker 
                    position={[activeOrder.courierCoords.lat, activeOrder.courierCoords.lng]}
                    icon={L.divIcon({
                      className: 'custom-icon',
                      html: '<div class="pulse-marker"></div>',
                      iconSize: [20, 20],
                      iconAnchor: [10, 10]
                    })}
                  >
                    <Popup>El repartidor está aquí</Popup>
                  </Marker>
                )}
                <MapUpdater center={
                  activeOrder.courierCoords 
                    ? [activeOrder.courierCoords.lat, activeOrder.courierCoords.lng] 
                    : [activeOrder.customerCoords.lat, activeOrder.customerCoords.lng]
                } />
              </>
            )}
          </MapContainer>
          
          <div className="absolute top-8 right-8 z-[1000]">
            <div className="bg-white/80 backdrop-blur-xl px-6 py-4 rounded-[28px] border border-white/50 shadow-2xl flex items-center gap-4">
              <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(34,197,94,0.5)]"></div>
              <span className="text-sm font-black text-slate-800 tracking-tight">
                {profile?.role === 'despachador' ? `Supervisando ${availableOrders.length} pedidos` : 
                 activeOrder?.status === 'en_camino' ? 'Carlos Mendoza está de camino' : 'Buscando el mejor repartidor para ti...'}
              </span>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
